#ifndef SYNCHRONIZATION_HPP
#define SYNCHRONIZATION_HPP

void lock_mocks_enable(bool enabled);
void condvar_mocks_enable(bool enabled);

#endif
