#ifndef SELECTOR_H
#define SELECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

int get_selector(void);

#ifdef __cplusplus
}
#endif

#endif
