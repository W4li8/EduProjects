test-runner
===========

A simple CppUTest runner for the CVRA packager.
