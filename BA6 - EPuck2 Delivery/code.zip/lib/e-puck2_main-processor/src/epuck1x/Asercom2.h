#ifndef _ASERCOM2
#define _ASERCOM2

#ifdef __cplusplus
extern "C" {
#endif

void run_asercom2(void);

#ifdef __cplusplus
}
#endif

#endif
