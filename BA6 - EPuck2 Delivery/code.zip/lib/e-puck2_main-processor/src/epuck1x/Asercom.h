#ifndef _ASERCOM
#define _ASERCOM

#ifdef __cplusplus
extern "C" {
#endif

void run_asercom(void);

#ifdef __cplusplus
}
#endif

#endif
