//
//  utilitaire.c
//
//  Created by Antoine Masanet and Filip Slezak.
//  Project Spring 2018 Decontaminators.
//

#include "utilitaire.h"

double util_distance(S2D a, S2D b) //
{
    return sqrt(pow(b.x-a.x, 2)+pow(b.y-a.y, 2));
}

double util_angle(S2D a, S2D b) //
{
	double diffX = b.x-a.x, diffY = b.y-a.y;
    double angle = atan2(diffY, diffX);
    util_range_angle(&angle);
    return angle;
}

void util_range_angle(double *p_angle) //
{
    if (!p_angle)
    {
        printf("%s:adresse NULL",__func__);
        exit(EXIT_FAILURE);
    }
    
    while (*p_angle<=-M_PI) *p_angle += 2*M_PI;
    while (*p_angle>M_PI) *p_angle -= 2*M_PI;
}

bool util_point_dehors(S2D a, double max) //
{
    return max < a.x || a.x < -max || max < a.y || a.y < -max;
}

bool util_alpha_dehors(double alpha) //
{
    return -M_PI > alpha || alpha > M_PI;
}

bool util_point_dans_cercle(S2D a, C2D c) //
{
	return util_distance(a, c.centre) < c.rayon-EPSIL_ZERO;
}

bool util_collision_cercle(C2D a, C2D b, double *p_dist) //
{
    if (!p_dist)
    {
        printf("%s:adresse NULL",__func__);
        exit(EXIT_FAILURE);
    }
    
    *p_dist = util_distance(a.centre, b.centre);
    
	return *p_dist < a.rayon+b.rayon-EPSIL_ZERO;
}

S2D util_deplacement(S2D p, double alpha, double dist)
{
	p.x += dist*cos(alpha);
	p.y += dist*sin(alpha);
	
	return p;
}

bool util_ecart_angle(S2D a, double alpha, S2D b, double *p_ecart_angle) //
{
	if( p_ecart_angle && util_distance(a, b) > EPSIL_ZERO)
	{
		*p_ecart_angle = util_angle(a, b)-alpha;
		util_range_angle(p_ecart_angle);
		return true;
	}
	return false;
}

bool util_alignement(S2D a, double alpha, S2D b)
{
    double ecartAngle;
    return  util_ecart_angle(a, alpha, b ,&ecartAngle)
            && fabs(ecartAngle) < EPSIL_ALIGNEMENT;
}

bool util_inner_triangle(double la, double lb, double lc, double lb_new,
						 double *p_la_new)
{
    if (la > EPSIL_ZERO && lc > EPSIL_ZERO && lb >= 0 && p_la_new )
    {
        double cosBeta = (pow(la, 2)+pow(lc, 2)-pow(lb, 2))/(2*la*lc);
    
        *p_la_new = lc*cosBeta-sqrt(pow(lc*cosBeta, 2)-pow(lc, 2)+pow(lb_new, 2));
        
        return true;
    }
    
    else return false;
}
