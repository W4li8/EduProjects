//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef ROBOT_H
#define ROBOT_H

#include <stdbool.h>

#include "constantes.h"
#include "tolerance.h"


//FONCTIONS "FICHIER"

/*Lit les informations du fichier et cree les strucutres correspondantes*/
void robot_lecture(char ligne[MAX_LINE]);

/*Verifie si les donnees entree par l'automate de lecture sont correctes et si il n'y
 a pas de collision ROBOT-ROBOT et PARTICULE-ROBOT,appelle les fonctions erreures
 correspondantes*/
bool robot_erreur(void);

/*Ecrit dans le fichier de sauvegarde toutes les informations correspondant aux
 particules avec la syntaxe appropriee*/
void robot_sauvegarde(FILE *fichier);

/*Remet tout les pointeurs a NULL, les variables globales a 0 et libere les structures
 des particules*/
void robot_toutEffacer(void);

//FONCTIONS AFFICHAGES

/*Affiche dans le terminal les informations de toutes les robots*/
void robot_afficher(void);

/*Appelle les fonctions de graphic avec les parametre de tous les robots pour
 les dessiner*/
void robot_dessin(void);

//FONCTIONS GET

/*Renvoie le nombre de robots(variable globale au module*/
int robot_get_nbRobot(void);
#endif /* robot_h */
