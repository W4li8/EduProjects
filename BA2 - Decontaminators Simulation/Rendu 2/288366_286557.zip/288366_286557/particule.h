//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef PARTICULE_H
#define PARTICULE_H


#include "constantes.h"
#include "utilitaire.h"

//PROTOTYPES DE FONCTIONS

////////////////////////////////FONCTIONS "FICHIER"////////////////////////////////////

/*Lit les informations du fichier et cree les strucutres correspondantes*/
void particule_lecture(char ligne[MAX_LINE]);

/*Verifie si les donnees entree par l'automate de lecture sont correctes et si il n'y a pas de collision PARTICULE-PARTICULE,appelle les fonctions erreures correspondantes*/
bool particule_erreur(void);

/*Fonction appellee par robot qui permet de verifier si il y a une collision entre le
 robot et une des particules du module.Renvoie l'indice de celle-ci*/
int particule_collisionRobotErreur(C2D robot);

/*Ecrit dans le fichier de sauvegarde toutes les informations correspondant aux
 particules avec la syntaxe appropriee*/
void particule_sauvegarde(FILE *fichier);

/*Remet tout les pointeurs a NULL, les variables globales a 0 et libere les structures
 des particules*/
void particule_toutEffacer(void);



//////////////////////////////FONCTIONS AFFICHAGE//////////////////////////////////////

/*Affiche dans le terminal les informations de toutes les particules*/
void particule_afficher (void);

/*Appelle les fonctions de graphic avec les parametre de toutes les particules pour
 les dessiner*/
void particule_dessin(void);

/////////////////////////////FONCTIONS GET/////////////////////////////////////////////

/*Renvoie le nombre de particules(variable globale au module*/
int particule_get_nbParticule(void);



#endif /* particle_h */
