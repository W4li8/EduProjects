//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
// graphic musts
#include <GL/glut.h>
#include <GL/glui.h>
// C files
extern "C" 
{
	#include "simulation.h"
	#include "graphic.h"
	#include "constantes.h"
}

namespace
{
	int main_window;

	int width, height;
	double ratio = 1;			

	bool stop = true, stepMode = false;
	int record, turn_count = 0;
	
	GLUI_Panel *panelOpen, *panelSave, 
			   *panelSim, *panelRecord,
			   *panelControlMode, *panelRobot;
    GLUI_EditText *fileOpen, *fileSave;
    GLUI_Button *start_stop;
    GLUI_RadioGroup *ctrl_mode;
    GLUI_StaticText *rate, *turn, 
					*vTran, *vRot;

	char temp[MAX_LINE];
}

#define OPEN -1
#define SAVE -2
#define STARTSTOP -3
#define STEP -4
#define RECORD -5
#define CONTROLMODE -6

#define AUTO 0
#define MANUAL 1

/** \brief  fonction callback pour glut lorsque le contenu doit etre redessine */
void display_cb( void );
/** \brief  taches a executer lorsque l'utilisateur ne fait rien */
void idle_cb( void );
/** \brief  gere le changement de taille de la fenetre/du widget */
void reshape_cb( int width, int height );
/** \brief  gere les actions de l'utilisateur */
void control_cb( int control );

/** \brief  cree le panneau de controle utilisateur */
void gluiInterface(void);
/** \brief  fonction principale de mise a jour des cycles */
void update( void );

/*		CALLBACKS		---------------------------------------------*/

void reshape_cb(int width, int height)
{
	ratio = ( (GLfloat) width )/( (GLfloat) height );
    glViewport( 0, 0, width, height );
    
    glutPostRedisplay();
}

void  display_cb()
{
	update();
}

void idle_cb()
{
	if( glutGetWindow() != main_window ) glutSetWindow( main_window );
	glutPostRedisplay();
}

void control_cb( int control )
{
	switch( control )
	{
		case OPEN:
			stop = true;
            start_stop->set_name( "Start" );
			simulation_initialisation( fileOpen->get_text() );
			turn_count = 0;
			glutPostRedisplay();
			break;
		case SAVE:
			simulation_sauvegarde( fileSave->get_text() );
			break;
		case STARTSTOP:
			stop = !stop;
			stepMode = false;
			if( stop ) start_stop->set_name( "Start" );
			else start_stop->set_name( "Stop" );
			break;
		case STEP:
			stop = true;
            start_stop->set_name( "Start" );
            stepMode = true;
			glutPostRedisplay();
			break;
		case RECORD:
			break;
		case CONTROLMODE: 
			if( ctrl_mode->get_int_val() == AUTO ) panelRobot->disable();
			else panelRobot->enable();
			break;
    }
}

/*		MAIN		---------------------------------------------*/

int main( int argc, char *argv[] )
{
	if( argc > 1 && strcmp( argv[1], "Error" ) == 0 ) 
	{
		simulation_activer_modeErreur();
		if( argc > 2 ) simulation_initialisation( argv[2] );
	}
	if( argc == 1 || strcmp( argv[1], "Draw" ) == 0 ) 
	{
		glutInit( &argc, argv );
		glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
		glutInitWindowPosition( 200, 50 );
		glutInitWindowSize( 500, 500 );
		
		main_window = glutCreateWindow( "Decontaminators" );
		
		glutReshapeFunc( reshape_cb );
		glutDisplayFunc( display_cb );
		glutIdleFunc( idle_cb );
		
		gluiInterface();

		srand(time(NULL));
		if( argc > 2 ) simulation_initialisation( argv[2] );
		
		glutMainLoop();
	}
	return 0;
}

void gluiInterface()
{
	GLUI *glui = GLUI_Master.create_glui( "Commandeur", 0, 710, 50 );
	glui->set_main_gfx_window( main_window );

//	Documents management
	panelOpen = glui->add_panel( "Opening" );
	fileOpen = glui->add_edittext_to_panel( panelOpen, "File name: ", 
											GLUI_EDITTEXT_TEXT );
	glui->add_button_to_panel( panelOpen, "Open", OPEN, control_cb );
	
	panelSave = glui->add_panel( "Saving" );
	fileSave = glui->add_edittext_to_panel( panelSave, "File name: ", 
											GLUI_EDITTEXT_TEXT );
	glui->add_button_to_panel( panelSave, "Save", SAVE, control_cb );
	
	glui->add_column(false);
//	Simulation management
	panelSim = glui->add_panel( "Simulation" );
	start_stop = glui->add_button_to_panel( panelSim, "Start", 
											STARTSTOP, control_cb );
	glui->add_button_to_panel( panelSim, "Step", STEP, control_cb );
	
	panelRecord = glui->add_panel( "Recording" );
	glui->add_checkbox_to_panel( panelRecord, "Record", 
								 &record, RECORD, control_cb );
	rate = glui->add_statictext_to_panel( panelRecord, "Rate: 0." ); 
	turn = glui->add_statictext_to_panel( panelRecord, "Turn: 0" );
						    
	glui->add_column(false);
//	Control management
	panelControlMode = glui->add_panel("Control Mode");
	ctrl_mode = glui->add_radiogroup_to_panel(panelControlMode, NULL, 
											  CONTROLMODE, control_cb);
	glui->add_radiobutton_to_group(ctrl_mode, "Automatic");
	glui->add_radiobutton_to_group(ctrl_mode, "Manual");
	
	panelRobot = glui->add_panel("Robot Control");
    vTran = glui->add_statictext_to_panel(panelRobot, "Translation: 0.");
    vRot = glui->add_statictext_to_panel(panelRobot, "Rotation: 0.");
	panelRobot->disable(); // mode automatique par defaut

	glui->add_button( "Exit", 0, (GLUI_Update_CB) exit );
}

void update()
{
    // efface le contenu de la fenetre
    glClearColor( 0.99, 0.96, 0.8, 0 ); // NB: lemon chiffon
    glClear( GL_COLOR_BUFFER_BIT );
    // definit le domaine de la simulation 
    glLoadIdentity();
    if( ratio <= 1 ) glOrtho( -DMAX, DMAX, -DMAX/ratio, DMAX/ratio, -1, 1 );
    else glOrtho( -DMAX*ratio, DMAX*ratio, -DMAX, DMAX, -1, 1 );
    // redessine le contenu actualise de la fenetre
	graphic_draw_axis();
    simulation_dessin();

    glutSwapBuffers();
}
