//
//  tolerance.c
//
//  Created by Ronan Boulic.
//  Project Spring 2018 Decontaminators.
//

#ifndef TOLERANCE_H
#define TOLERANCE_H

#define EPSIL_ZERO 1e-2
#define EPSIL_ALIGNEMENT 0.0625

#endif /* TOLERANCE_H */
