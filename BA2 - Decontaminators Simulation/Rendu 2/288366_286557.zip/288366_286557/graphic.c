//
//  graphic.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#include "graphic.h"

#include <stdio.h>
#include <stdbool.h>
#include <math.h>

#include <GL/glu.h>

#include "constantes.h"

#define GRAPHIC_EMPTY 0
#define GRAPHIC_FILLED 1
#define COTES 60
#define GRAD 0.25


/** \brief  dessine une ligne entre (x1, y1) et (x2, y2) */
void graphic_ligne(double x1, double y1, double x2, double y2)
{
    glBegin (GL_LINES);

    glVertex2f (x1, y1);
    glVertex2f (x2, y2);

    glEnd ();
}
/** \brief  dessine un cercle de centre (x, y) */
void graphic_cercle(double rayon, double x, double y, int type)
{
    double alpha;

    if(type == GRAPHIC_FILLED) glBegin(GL_POLYGON);
    else glBegin(GL_LINE_LOOP);

    for (int i = 0; i < COTES; i++)
    {
        alpha = i*2*M_PI/COTES;
        glVertex2f(x+rayon*cos(alpha), y+rayon*sin(alpha));
    }
    glEnd ();
}

void graphic_robot(double x, double y, double alpha, bool autonome)
{
    glColor3f(1,1,1);
    if(!autonome) glColor3f(1,0,0.5); // fuschia pour controle manuel
    graphic_cercle(R_ROBOT, x, y, GRAPHIC_FILLED);
    glColor3f(0,0,0);
    graphic_cercle(R_ROBOT, x, y, GRAPHIC_EMPTY);

    glColor3f(1,0.3,0); // orange pour la direction
    graphic_ligne(x, y, x+R_ROBOT*cos(alpha), y+R_ROBOT*sin(alpha));
}

void graphic_particule(double energie, double rayon, double x, double y, bool libre)
{
    glColor3f(0.4,0.2,0); // brun, couleur en fonction de l'energie
    if(energie > 0.25) glColor3f(0.2,0.4,0); // green
    if(energie > 0.50) glColor3f(0,0.3,0.6); // blue
    if(energie > 0.75) glColor3f(0.8,0,0); // red
    if(!libre) glColor3f(1,0,0); // rouge pur si ciblee par un robot

    graphic_cercle(rayon, x, y, GRAPHIC_FILLED);
}

void graphic_draw_axis(void)
{
    glColor3f(0,0,0); // ne tient pas compte de l'epaisseur de la ligne

    graphic_ligne(-DMAX, 0, DMAX, 0);
    graphic_ligne(0, -DMAX, 0, DMAX);

    for(int i =-DMAX;i<=DMAX;i++)
    {
        graphic_ligne(i, GRAD, i, -GRAD);
        graphic_ligne(GRAD, i, -GRAD, i);
    }
}
