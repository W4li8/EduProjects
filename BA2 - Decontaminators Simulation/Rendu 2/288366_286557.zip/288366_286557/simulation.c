//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//


#include "utilitaire.h"
#include <string.h>
#include <stdbool.h>

#include "simulation.h"
#include "robot.h"
#include "particule.h"
#include "error.h"

static bool modeError=false;

enum {NB_ROBOT, INFO_ROBOT, NB_PARTICULE, INFO_PARTICULE};

/** \brief    lit les donnees depuis le fichier */
bool simulation_lecture(const char *ptr_fichier);
/** \brief    verifie l'exactitude des donnees du fichier */
bool simulation_erreur(int etat,int nbEntite,int numLigne);
/** \brief    efface les donnees et remet les variables a zero en appelant les
 fonctions toutEffacer de robot.c et particule.c  */
void simulation_toutEffacer(void);

void simulation_activer_modeErreur()
{
    modeError=true;
}

void simulation_initialisation(const char *ptr_fichier)
{
    simulation_toutEffacer();

    if (modeError)
    {
        if(simulation_lecture(ptr_fichier)) exit(EXIT_FAILURE);
        else error_no_error_in_this_file();
    }
    else
    {
        if (simulation_lecture(ptr_fichier)) simulation_toutEffacer();
        else error_no_error_in_this_file();
    }
}

bool simulation_lecture(const char *ptr_fichier)
{
    FILE *fichier = fopen(ptr_fichier, "r");
    if(fichier)
    {
        int i, nbRobot = 0, nbParticule = 0, etapeLecture = NB_ROBOT, numLigne = 0;
        char ligne[MAX_LINE];

        while(fgets(ligne, MAX_LINE, fichier) != NULL)//Consomme une ligne
        {
            numLigne++;
            for(i = 0; ligne[i] == ' ' || ligne[i] == '\t'; i++);
            if(!(ligne[i] == '#' || ligne[i] == '\n' || ligne[i] == '\r'))
            {
                switch(etapeLecture)
                {
                    case NB_ROBOT:
                        if(sscanf(ligne, " %d", &nbRobot) != 1)
                            error_invalid_robot();//Pas demande
                        etapeLecture = INFO_ROBOT;
                        break;

                    case INFO_ROBOT:
                        if(strcmp(ligne, "FIN_LISTE\n")==0)
                            if(simulation_erreur(INFO_ROBOT,nbRobot,numLigne))
                                return true;

                        if(strcmp(ligne, "FIN_LISTE\n")==0 &&
                           nbRobot==robot_get_nbRobot())
                            etapeLecture = NB_PARTICULE;
                        robot_lecture(ligne);
                        break;

                    case NB_PARTICULE:
                        if(sscanf(ligne, " %d", &nbParticule) != 1)
                            error_invalid_particule();//Pas demande
                        etapeLecture = INFO_PARTICULE;
                        break;

                    case INFO_PARTICULE:
                        if(strcmp(ligne, "FIN_LISTE\n")==0)
                            if(simulation_erreur(INFO_PARTICULE,nbParticule,numLigne))
                                return true;
                        particule_lecture(ligne);
                        break;
                }
            }
        }
        fclose(fichier);
        return false;
    }
    else error_file_missing(ptr_fichier);
    return true;
}

bool simulation_erreur(int etat,int nbEntite,int numLigne)
{
    if(etat==INFO_ROBOT)
    {
        if(nbEntite>robot_get_nbRobot())
        {
            error_fin_liste_robots(numLigne);
            return true;
        }
        else if(nbEntite<robot_get_nbRobot())
        {
            error_missing_fin_liste_robots(numLigne);
            return true;
        }
    }

    if(etat==INFO_PARTICULE)
    {
        if(nbEntite==particule_get_nbParticule())
        {
            if (particule_erreur())return true;
            if (robot_erreur())return true;
        }

        else if(nbEntite>particule_get_nbParticule())
        {
            error_fin_liste_particules(numLigne);
            return true;
        }
        else if(nbEntite<particule_get_nbParticule())
        {
            error_missing_fin_liste_particules(numLigne);
            return true;
        }
    }
    return false;
}

void simulation_toutEffacer(void)
{
    robot_toutEffacer();
    particule_toutEffacer();
}

void simulation_sauvegarde(const char *ptr_fichier)
{
    FILE *fichier = fopen(ptr_fichier, "w");
    if(fichier)
    {
        robot_sauvegarde(fichier);
        particule_sauvegarde(fichier);
        fclose(fichier);
    }
    else
    {
        printf("Entrée NULL");
    }
}

void simulation_dessin(void)
{
    robot_dessin();
    particule_dessin();
}



