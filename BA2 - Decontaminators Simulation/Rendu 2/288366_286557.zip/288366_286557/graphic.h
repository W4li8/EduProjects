//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef GRAPHIC_H
#define GRAPHIC_H

#include <stdio.h>
#include <stdbool.h>

/** \brief  dessine un robot */
void graphic_robot(double x, double y, double alpha, bool autonome);
/** \brief  dessine une particule */
void graphic_particule(double energie, double rayon, double x, double y, bool libre);
/** \brief  dessine les axes du monde */
void graphic_draw_axis(void);

#endif /* GRAPHIC_H */

