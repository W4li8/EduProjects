//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//
#include <stdio.h>
#include <stdlib.h>

#include "robot.h"
#include "particule.h"
#include "graphic.h"
#include "error.h"
#include "utilitaire.h"

typedef struct Robot ROBOT;
struct Robot
{
    C2D cercle;
    double angle;
    bool actif;//rendu 3
    bool autonome;//rendu 3
    C2D cible;//rendu 3
    ROBOT* prochain;//Pointe sur le prochain robot
};

//Variables globales au module
static int nbRobot=0;
static ROBOT *teteListe;

//Controle manuel du robot
static double vLin;
static double vRot;
///////////////////////////////////////////////////////////////////////////////////////

/*Alloue de la memoire pour la structure d'un robot et chaine celui-ci avec les
 autres, assigne a la structure les valeurs en entrée*/
void robot_creation (double x, double y, double angle);

///////////////////////////////////////////////////////////////////////////////////////
void robot_creation (double x, double y, double angle)
{
    ROBOT *nouveau = (ROBOT*)malloc(sizeof(*nouveau));

    if (nouveau == NULL)
    {
        printf("%s:adressse NULL",__func__);
    }

    // L'element suivant ce nouvel element est l'ancien premier
    nouveau->prochain = teteListe;
    teteListe = nouveau;

    nouveau->angle=angle;
    nouveau->cercle.rayon = R_ROBOT;;
    nouveau->cercle.centre.x = x;
    nouveau->cercle.centre.y = y;
    nouveau->autonome=true;
    nouveau->actif=true;
    nbRobot++;
}


void robot_lecture(char ligne[MAX_LINE])
{
    char *ptrligne = ligne;
    double robotX, robotY, robotAngle;

    while(sscanf(ptrligne, " %lf %lf %lf", &robotX, &robotY, &robotAngle) == 3)
    {
        robot_creation(robotX, robotY, robotAngle);
        for(int i = 0; i < 3; i++) strtod(ptrligne,  &ptrligne);
    }

}

void robot_sauvegarde(FILE *fichier)
{
    ROBOT* robot=teteListe;

    fprintf(fichier, "# nb_robot\n%d\n# info_robot\n",nbRobot);

    while (robot)
    {
        fprintf(fichier, "%f %f %f\n",robot->cercle.centre.x,
                robot->cercle.centre.y,robot->angle);

        robot=robot->prochain;
    }
    fprintf(fichier,"FIN_LISTE\n\n");
}

bool robot_erreur()
{
    int i=0,j=0;
    ROBOT *robot1=teteListe,*robot2=NULL;
    double dist;//Sert a rien mais necessaire pour employer utilitaire

    while(robot1)
    {
        if (util_alpha_dehors(robot1->angle))
        {
            error_invalid_robot_angle(robot1->angle);
            return true;
        }
        robot1=robot1->prochain;
    }

    robot1=teteListe;
    while(robot1)
    {
        robot2=robot1;
        j=0;
        while(robot2)
        {
            if (robot1!=robot2 && util_collision_cercle(robot1->cercle,robot2->cercle,
														&dist))
            {
				//robot dans ordre oppose
                error_collision(ROBOT_ROBOT,nbRobot-i,nbRobot-j);
                return true;
            }
            robot2=robot2->prochain;
            j++;
        }
        robot1=robot1->prochain;
        i++;
    }
    robot1=teteListe;
    i=0;
    while(robot1)
    {
        //Renvoie l'indice de la particule et 0 si pas de collision
        j=particule_collisionRobotErreur(robot1->cercle);
        if (j)
        {
            //On sauvegarde les robots dans l'ordre oppose donc on
            //doit changer les indices
            error_collision(ROBOT_PARTICULE,nbRobot-i,j);
            return true;
        }
        robot1=robot1->prochain;
        i++;
    }
    return false;
}


void robot_toutEffacer()
{
    ROBOT *robot=teteListe;
    ROBOT *temp;

    while(robot)
    {
        temp=robot->prochain;
        free(robot);
        robot=temp;
    }
    teteListe=NULL;
    nbRobot=0;
}

void robot_afficher(void)
{
    ROBOT* robot=teteListe;
    while(robot)
    {
        printf("x:%lf y:%lf Angle:%lf\n",robot->cercle.centre.x,
               robot->cercle.centre.y,robot->angle);
        robot=robot->prochain;

    }
}


int robot_get_nbRobot()
{
    return nbRobot;
}

void robot_dessin(void)
{
    ROBOT *robot=teteListe;
    while(robot)
    {
        util_dessinRobot(robot->cercle.centre.x,robot->cercle.centre.y,robot->angle,
                         robot->autonome);
        robot=robot->prochain;
    }
}



