//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef SIMULATION_H
#define SIMULATION_H

/** \brief    declenche le  mode erreur du programme si appelee */
void simulation_activer_modeErreur(void);
/** \brief    initialise les donnees de la simulation a partir du ficher pointe */
void simulation_initialisation(const char *ptr_fichier);
/** \brief    sauvegarde les donnees actuelles dans le fichier pointe */
void simulation_sauvegarde(const char *ptr_fichier);
/** \brief    appelle les fonctions dessin de robot et particules */
void simulation_dessin(void);

#endif

