//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "particule.h"
#include "constantes.h"
#include "error.h"
#include "graphic.h"
#include "tolerance.h"

typedef struct Particule PARTICULE;

struct Particule
{
    double energie;
    C2D cercle;//Rayon + Coordonnees
    PARTICULE *prochain;//Pointeur sur le prochain element de la liste
    PARTICULE *precedent;//Pointeur sur le precedent element de la liste
    bool libre;//Indique si un robot la selectionne(rendu 3)
    int zone;//Determine sa zone(rendu 3)
};


static PARTICULE *teteListe = NULL;//Pointe sur la premiere particule

static int nbParticule = 0;


/*Alloue de la memoire pour la structure d'une particule et chaine celle-ci avec les
 autres, assigne a la structure les valeurs en entrée*/
void particule_creation (double energie, double rayon, double x, double y);

/*Supprime une particule en refermant la chaine au préalable*/
void particule_suppression (PARTICULE *particule);

void particule_creation (double energie, double rayon, double x, double y)
{
    //Alloue de la memoire pour le nouvel element
    PARTICULE *nouveau =(PARTICULE*) malloc(sizeof(*nouveau));

    if (nouveau == NULL)
    {
        printf("%s:adressse NULL",__func__);
        exit(EXIT_FAILURE);
    }
    //L'ancien premier element recoit ce nouveau comme predecesseur
    if (teteListe != NULL) teteListe->precedent = nouveau;

    // L'element suivant ce nouvel element est l'ancien premier
    nouveau->prochain = teteListe;
    nouveau->precedent = NULL;
    teteListe = nouveau;

    nouveau->energie = energie;
    nouveau->cercle.rayon = rayon;
    nouveau->cercle.centre.x = x;
    nouveau->cercle.centre.y = y;
    nouveau->libre=true;
    nbParticule++;
}


void particule_suppression (PARTICULE *particule)
{
    if (particule==NULL)
    {
        printf("%s:adresse NULL",__func__);
        exit(EXIT_FAILURE);
    }
    if (particule->prochain)//Si la particule pointe sur une autre en prochain
    {
        particule->prochain->precedent = particule->precedent;
    }

    if (particule->precedent)//Si la particule possede un precedent
    {
        particule->precedent->prochain = particule->prochain;
    }

    else teteListe=particule->prochain;

    free(particule);

    nbParticule--;
}

void particule_lecture(char ligne[MAX_LINE])
{
    char *ptrligne = ligne;
    double particuleEnergie, particuleRayon, particuleX, particuleY;

    while(sscanf(ptrligne, " %lf %lf %lf %lf",
                 &particuleEnergie, &particuleRayon, &particuleX, &particuleY) == 4)
    {
        particule_creation(particuleEnergie, particuleRayon, particuleX, particuleY);
        for(int i = 0; i < 4; i++) strtod(ptrligne,  &ptrligne);
    }
}

void particule_sauvegarde(FILE *fichier)
{
    PARTICULE *particule = teteListe;

    fprintf(fichier, "# nb_particule\n%d\n# info_particule\n", nbParticule);

    while(particule)
    {
        fprintf(fichier, "%lf %lf %lf %lf\n",
                particule->energie, particule->cercle.rayon,
                particule->cercle.centre.x, particule->cercle.centre.y);

        particule = particule->prochain;
    }

    fprintf(fichier,"FIN_LISTE\n");
}

bool particule_erreur()
{
    PARTICULE *particule1=teteListe;
    PARTICULE *particule2;

    double energie,rayon,dist;
    int i=1,j=1;
    S2D pos;

    while(particule1)
    {
        energie = particule1->energie;
        rayon = particule1->cercle.rayon;
        pos.x = particule1->cercle.centre.x;
        pos.y = particule1->cercle.centre.y;

        if (energie>E_PARTICULE_MAX || rayon<R_PARTICULE_MIN
            || rayon>R_PARTICULE_MAX || util_point_dehors(pos,DMAX))
        {
            error_invalid_particule_value(energie, rayon, pos.x, pos.y);
            return true;
        }
        particule1 = particule1->prochain;
    }

    particule1=teteListe;

    while(particule1)
    {
        particule2=particule1;
        j=i;

        while(particule2)
        {
            if (particule1!=particule2 &&
                util_collision_cercle(particule1->cercle,particule2->cercle,&dist))
            {
                error_collision(PARTICULE_PARTICULE,i,j);
                return true;
            }
            particule2=particule2->prochain;
            j++;
        }
        particule1=particule1->prochain;
        i++;
    }
    return false;
}

int particule_collisionRobotErreur(C2D robot)
{
    int i=0;
    double dist;
    PARTICULE *particule=teteListe;
    while (particule)
    {
        //Ici, les particules etant cree dans l'ordre inverse, on remet les indices
        //dans le bon ordre
        if(util_collision_cercle(particule->cercle,robot,&dist)) return nbParticule-i;

        i++;
        particule=particule->prochain;
    }

    return 0;
}

void particule_afficher (void)
{
    PARTICULE *particule=teteListe;

    while(particule)
    {
        printf("Energie:%lf Rayon:%lf x:%f y:%f\n",
			   particule->energie, particule->cercle.rayon,
               particule->cercle.centre.x,particule->cercle.centre.y);

        particule=particule->prochain;
    }
}

void particule_toutEffacer()
{
    PARTICULE *particule=teteListe;

    while(particule)
    {
        particule_suppression(particule);
        particule=teteListe;
    }
    nbParticule=0;
}

int particule_get_nbParticule(void)
{
    return nbParticule;
}

void particule_dessin(void)
{
    PARTICULE *particule=teteListe;
    while(particule)
    {
        util_dessinParticule(particule->energie, particule->cercle.rayon,
                             particule->cercle.centre.x,
                             particule->cercle.centre.y,particule->libre);
        particule=particule->prochain;
    }
}


