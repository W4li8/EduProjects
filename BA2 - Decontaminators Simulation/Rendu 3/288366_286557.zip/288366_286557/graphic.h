//
//  graphic.h
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef GRAPHIC_H
#define GRAPHIC_H

/** \brief  change la couleur de dessin */
void graphic_set_colour(int colour);
/** \brief  change l'epaisseur du trait */
void graphic_line_width(int width);
/** \brief  dessine un cercle de centre (x, y) */
void graphic_cercle(double rayon, double x, double y, int type);
/** \brief  dessine une ligne entre a(x1, y1) et b(x2, y2) */
void graphic_ligne(double x1, double y1, double x2, double y2);

#endif /* GRAPHIC_H */

