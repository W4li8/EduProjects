//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "simulation.h"
#include "robot.h"
#include "particule.h"
#include "error.h"
#include "utilitaire.h"

//////////////////////////VARIABLES GLOBALES AU MODULE/////////////////////////////////

enum {NB_ROBOT, INFO_ROBOT, NB_PARTICULE, INFO_PARTICULE};

static bool modeError=false;
static char *fichier_enregistrement = "out.dat";

/////////////////FONCTIONS NON EXPORTEES PAR LE MODULE/////////////////////////////////
/*Verifie si le fichier lu est correcte et sinon appelle les fonctions d'error.c
 correspondante*/
bool simulation_erreur(int etat,int nbEntite,int numLigne);

/*Lit le fichier rentré par l'utilisateur et appelle les fonctions de robot et
 particule qui implente les donnees*/
bool simulation_lecture(const char *ptr_fichier);

/*Appelle les fonctions de robot et particule qui effacent toutes les donnees*/
void simulation_toutEffacer(void);
///////////////////////////////////////////////////////////////////////////////////////
void simulation_enregistrement(int tour)
{
    FILE *fichier = fopen(fichier_enregistrement, "a");
    if(fichier)
	{
        fprintf(fichier, "%d %lf\n", tour, particule_get_deconRate());
        fclose(fichier);
    }
	else printf("ERROR - NO FILE - for %s();", __func__);
}

double simulation_get_deconRate()
{
    return particule_get_deconRate();
}

void simulation_robot_vTran(int multiplier)
{
    robot_vTran(multiplier);
}

void simulation_robot_vRot(int multiplier)
{
    robot_vRot(multiplier);
}

double simulation_get_robot_vTran()
{
	return robot_get_vTran();
}

double simulation_get_robot_vRot()
{
	return robot_get_vRot();
}

void simulation_activer_modeErreur()
{
    modeError=true;
}

void simulation_initialisation(const char fichier[])
{
    simulation_toutEffacer();

    if (modeError)
    {
        if(simulation_lecture(fichier)) exit(EXIT_FAILURE);
        else error_no_error_in_this_file();
    }
    else
    {
        if (simulation_lecture(fichier)) simulation_toutEffacer();
        else error_no_error_in_this_file();
    }
 }

bool simulation_lecture(const char *ptr_fichier)
{
    FILE *fichier = fopen(ptr_fichier, "r");
    if(fichier)
    {
        int i, nbRobot = 0, nbParticule = 0, etapeLecture = NB_ROBOT, numLigne = 0;
        char ligne[MAX_LINE];

        while(fgets(ligne, MAX_LINE, fichier) != NULL)//Consomme une ligne
        {
            numLigne++;
            for(i = 0; ligne[i] == ' ' || ligne[i] == '\t'; i++);
            if(!(ligne[i] == '#' || ligne[i] == '\n' || ligne[i] == '\r'))
            {
                switch(etapeLecture)
                {
                    case NB_ROBOT:
                        if(sscanf(ligne, " %d", &nbRobot) != 1)
                            error_invalid_robot();
                        etapeLecture = INFO_ROBOT;
                        break;

                    case INFO_ROBOT:
                        if(strcmp(ligne, "FIN_LISTE\n")==0)
                            if(simulation_erreur(INFO_ROBOT,nbRobot,numLigne))
                                return true;

                        if(strcmp(ligne, "FIN_LISTE\n")==0 &&
                           	nbRobot==robot_get_nbRobot())
                            etapeLecture = NB_PARTICULE;
                        robot_lecture(ligne);
                        break;

                    case NB_PARTICULE:
                        if(sscanf(ligne, " %d", &nbParticule) != 1)
                            error_invalid_particule();
                        etapeLecture = INFO_PARTICULE;
                        break;

                    case INFO_PARTICULE:
                        if(strcmp(ligne, "FIN_LISTE\n")==0)
                            if(simulation_erreur(INFO_PARTICULE,nbParticule,numLigne))
                                return true;
                        particule_lecture(ligne);
                        break;
                }
            }
        }
        fclose(fichier);
        return false;
    }
    else error_file_missing(ptr_fichier);
    return true;
}

bool simulation_erreur(int etat,int nbEntite,int numLigne)
{
    if(etat==INFO_ROBOT)
    {
        if(nbEntite>robot_get_nbRobot())
        {
            error_fin_liste_robots(numLigne);
            return true;
        }
        else if(nbEntite<robot_get_nbRobot())
        {
            error_missing_fin_liste_robots(numLigne);
            return true;
        }
    }

    if(etat==INFO_PARTICULE)
    {
        if(nbEntite==particule_get_nbParticule())
        {
            if (particule_erreur())return true;
            if (robot_erreur())return true;
        }

        else if(nbEntite>particule_get_nbParticule())
        {
            error_fin_liste_particules(numLigne);
            return true;
        }
        else if(nbEntite<particule_get_nbParticule())
        {
            error_missing_fin_liste_particules(numLigne);
            return true;
        }
    }
    return false;
}

void simulation_toutEffacer(void)
{
    //Efface le fichier out.dat
	FILE *fichier = fopen(fichier_enregistrement, "w");
	if(fichier) fclose(fichier);
	else printf("ERROR - NO FILE - for %s();", __func__);

    robot_toutEffacer();
    particule_toutEffacer();
}

void simulation_sauvegarde(const char *ptr_fichier)
{
    FILE *fichier = fopen(ptr_fichier, "w");
    if(fichier)
    {
        robot_sauvegarde(fichier);
        particule_sauvegarde(fichier);
        fclose(fichier);
    }
    else
    {
        printf("POINTEUR NULL");
        exit(EXIT_FAILURE);
    }
}

void simulation_operations(void)
{
    particule_operation();
    robot_operation();
}

void simulation_dessin(void)
{
	//dessin cadre
	util_dessin_ligne(-DMAX, DMAX, DMAX, DMAX, GRIS, EPAIS);
	util_dessin_ligne(DMAX, DMAX, DMAX, -DMAX, GRIS, EPAIS);
	util_dessin_ligne(DMAX, -DMAX, -DMAX, -DMAX, GRIS, EPAIS);
	util_dessin_ligne(-DMAX, -DMAX, -DMAX, DMAX, GRIS, EPAIS);
	//dessin des axes
	util_dessin_ligne(-DMAX, 0, DMAX, 0, GRIS, FIN);
    util_dessin_ligne(0, -DMAX, 0, DMAX, GRIS, FIN);
    for(int i = -DMAX+1; i < DMAX; i++)
    {
        util_dessin_ligne(i, GRAD, i, -GRAD, GRIS, FIN);
        util_dessin_ligne(GRAD, i, -GRAD, i, GRIS, FIN);
    }
	
    particule_dessin();
    robot_dessin();
}

void simulation_robotSelection(double x, double y)
{
    robot_selection(x,y);
}

void simulation_robotDeselection(void)
{
    robot_deselection();
}

bool simulation_finDecontamination(void)
{
    return !particule_get_nbParticule();
}
