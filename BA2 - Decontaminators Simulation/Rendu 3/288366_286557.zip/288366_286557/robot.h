//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef ROBOT_H
#define ROBOT_H

#include <stdio.h>
#include <stdbool.h>

#include "constantes.h"

//////////////////////////FONCTIONS "FICHIER"//////////////////////////////////////////

/*Gere la lecture du tableau extrait du fichier et crée les robots correspondants*/
void robot_lecture(char ligne[MAX_LINE]);
/*Detecte si il y des erreurs dans les donnees des robots recuperee*/
bool robot_erreur(void);
/*Ecrit dans le fichier correspondant toutes les donnees des robots */
void robot_sauvegarde(FILE *fichier);
/*Libere toutes les structures de robot et reinitialisae les variables globales*/
void robot_toutEffacer(void);

//////////////////////////////////////FONCTIONS AFFICHAGES/////////////////////////////

/*Affiche dans le terminal les donnees de tous les robots*/
void robot_afficher(void);
/*Appelle pour chaque robot la fonction d'utilitaire en charge du dessin des robots*/
void robot_dessin(void);

//////////////////////////////////FONCTIONS SIMULATION/////////////////////////////////

/*Pour chaque robot,effectue son déplacement*/
void robot_operation(void);
/*Permet de savoir si la souris pointe sur un robot et si oui, l'inscrit dans sa
 structure*/
void robot_selection (double x, double y);
/*Deselectionne tous les robots */
void robot_deselection (void);
/*Augmente ou diminue la vitesse de translation du robot*/
void robot_vTran(int multiplier);
/*Augmente ou diminue la vitesse de rotation du robot*/
void robot_vRot(int multiplier);

///////////////////////////////////////FONCTIONS GET///////////////////////////////////

/*Renvoie le nombre de robot*/
int robot_get_nbRobot(void);
/*Renvoie la vitesse de translation du robot controlle manuellement*/
double robot_get_vTran(void);
/*Renvoie la vitesse de rotation du robot controlle manuellement*/
double robot_get_vRot(void);
#endif /* robot_h */
///////////////////////////////////////////////////////////////////////////////////////
