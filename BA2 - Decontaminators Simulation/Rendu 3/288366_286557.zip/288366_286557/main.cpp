//
//  main.cpp
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//
//  Additional instructions can be found in "Aa ReadMe Help.txt".
//

#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//  graphic
#include <GL/glut.h>
#include <GL/glui.h>

//  C files
extern "C"
{
 	#include "simulation.h"
 	#include "constantes.h"
}
// 	symbols
enum { OPEN = -5, SAVE, STARTSTOP, STEPMODE, CONTROLMODE };

#define MANUAL	 1
#define AUTO 	 0

#define UP		 1
#define DOWN 	-1
#define LEFT	 1
#define RIGHT   -1
//  codes ASCII - explications d'usage dans "Aa ReadMe Help.txt"
	// nombres hexadecimaux
enum { H1 = 49, H2, H3, H4, H5, H6, H7, H8, H9 };
enum { HA = 65, HB, HC, HD, HE, HF };
	// autres caracteres
#define ECART 	32
#define ENTER 	13 
#define SPACE 	32 

#define MAJ  	95

namespace
{
	//variables globales
    int main_window;
    int width, height;
    double ratio = 1;

    bool stop = true, stepMode = false;
    int record, turn_count = 0;

 	GLUI_EditText *fileOpen, *fileSave;
    GLUI_Button *start_stop;
    GLUI_StaticText *rate, *turn,
 					*vTran, *vRot;
 	GLUI_Panel *panelRobot;
    GLUI_RadioGroup *ctrl_mode;
    
    char * file_selected_by_nb = NULL;
}
// 	functions
/** \brief  cree le panneau de controle utilisateur */
void create_user_control_interface( void );

/** \brief  fonction callback pour glut lorsque le contenu doit etre redessine */
void display_cb( void );
/** \brief  gere le changement de taille de la fenetre/du widget */
void reshape_cb( int width, int height );
/** \brief  taches a executer lorsque l'utilisateur ne fait rien, MAJ simulation */
void idle_cb( void );

/** \brief  gere les actions generees par la souris */
void mouse( int button, int state, int x, int y );
/** \brief  facilite les controles de la simulation pour l'utilisateur */
void keyboard( unsigned char key, int x, int y );
/** \brief  selection du fichier pointe pour chaque valeur de key */
bool define_file_selected_by_nb( int key );
/** \brief  gere les actions necessaires pour le controle du robot */
void keyboard_special( int key, int x, int y );

/** \brief  gere les appels de l'utilisateur */
void control_cb( int control );
/** \brief  re-initialise les valeurs de la simulation */
void prepare_new_simulation( void );
/** \brief  met a jour le panneau de la simulation */
void update_user_interface_simulation_values( void );
/** \brief  met a jour le panneau de controle utilisateur */
void update_user_interface_control_values( void );

/*        CALLBACKS        ---------------------------------------------*/

void display_cb()
{
    glClearColor( 0.99, 0.96, 0.8, 0 ); // lemon chiffon
    glClear( GL_COLOR_BUFFER_BIT );

    glLoadIdentity();
    if( ratio <= 1 )
        glOrtho( -DMAX, DMAX, -DMAX/ratio, DMAX/ratio, -1, 1 );
    else glOrtho( -DMAX*ratio, DMAX*ratio, -DMAX, DMAX, -1, 1 );

    simulation_dessin();
    
    glutSwapBuffers();
}

void reshape_cb(int width, int height)
{
    ratio = ( (GLfloat) width )/( (GLfloat) height );
    glViewport( 0, 0, width, height );

    glutPostRedisplay();
}

void idle_cb()
{
    if( glutGetWindow() != main_window ) glutSetWindow( main_window );
    
    if( ( !stop || stepMode ) && !simulation_finDecontamination() )
    {
        simulation_operations();
        if( record ) simulation_enregistrement( turn_count );
		update_user_interface_simulation_values();
		        
		stepMode = false;
        turn_count++;
    }
    glutPostRedisplay();
}

void control_cb( int control )
{
    switch( control )
    {
        case OPEN:
            stop = true;
			simulation_initialisation( fileOpen->get_text() );
            prepare_new_simulation();
            start_stop->set_name( "Start" );
            break;
        case SAVE:
            simulation_sauvegarde( fileSave->get_text() );
            break;
        case STARTSTOP:
            stop = !stop;
            stepMode = false;
            if( stop ) 
            {
				start_stop->set_name( "Start" );
				record = false;
			    GLUI_Master.sync_live_all(); // untick la checkbox record
			}
            else start_stop->set_name( "Stop" );
            break;
        case STEPMODE:
            stop = true;
            stepMode = true;
            start_stop->set_name( "Start" );
            break;
        case CONTROLMODE:
            if( ctrl_mode->get_int_val() == AUTO ) 
            {
				simulation_robotDeselection();
				update_user_interface_control_values();
				panelRobot->disable();
			}
            else panelRobot->enable();
            break;
    }
}

/*        MAIN        ---------------------------------------------*/
/** \brief	lance la simulation en fonction du mode demande */
int main( int argc, char *argv[] )
{
    if( argc > 1 && strcmp( argv[1], "Error" ) == 0 )
    {
        simulation_activer_modeErreur(); // argc vaut 3 normalement dans ce cas
        if( argc > 2 ) simulation_initialisation( argv[2] );
    }
    if( argc == 1 || strcmp( argv[1], "Draw" ) == 0 )
    {
        glutInit( &argc, argv );
        glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
        glutInitWindowPosition( 200, 50 );
        glutInitWindowSize( 500, 500 );

        main_window = glutCreateWindow( "Decontaminators" );

        glutReshapeFunc( reshape_cb );
        glutDisplayFunc( display_cb );
        glutIdleFunc( idle_cb );

        create_user_control_interface();

		system("cat Aa_ReadMe_Help.txt");

        srand( time( NULL ) );
        if( argc > 2 ) simulation_initialisation( argv[2] );
        
        glutMainLoop();
    }
    return EXIT_SUCCESS;
}

void prepare_new_simulation( void )
{
	turn_count = 0;
	record = false;
	GLUI_Master.sync_live_all(); // untick la checkbox record
	update_user_interface_simulation_values();
	
	ctrl_mode->set_int_val( AUTO );	
	update_user_interface_control_values();
	panelRobot->disable();
}

void create_user_control_interface()
{
    GLUI *glui = GLUI_Master.create_glui( "Commandeur", 0, 710, 50 );
    glui->set_main_gfx_window( main_window );

    GLUI_Master.set_glutMouseFunc( mouse );
    GLUI_Master.set_glutKeyboardFunc( keyboard );
    GLUI_Master.set_glutSpecialFunc( keyboard_special );
	//	Documents management
    GLUI_Panel *panelOpen = glui->add_panel( "Opening" );
    fileOpen = glui->add_edittext_to_panel( panelOpen, "File name: ", 
											GLUI_EDITTEXT_TEXT );
	fileOpen->set_text( ".txt" ); 							
    glui->add_button_to_panel( panelOpen, "Open", OPEN, control_cb );

    GLUI_Panel *panelSave = glui->add_panel( "Saving" );
    fileSave = glui->add_edittext_to_panel( panelSave, "File name: ", 
											GLUI_EDITTEXT_TEXT );
    fileSave->set_text( ".txt" );
    glui->add_button_to_panel( panelSave, "Save", SAVE, control_cb );

    glui->add_column( false );
	//  Simulation management
    GLUI_Panel *panelSim = glui->add_panel( "Simulation" );
    start_stop = glui->add_button_to_panel( panelSim, "Start", STARTSTOP, control_cb );
    glui->add_button_to_panel( panelSim, "Step", STEPMODE, control_cb );

    GLUI_Panel *panelRecord = glui->add_panel( "Recording" );
    glui->add_checkbox_to_panel( panelRecord, "Record", &record );
    rate = glui->add_statictext_to_panel( panelRecord, "Rate: loading..." );
    turn = glui->add_statictext_to_panel( panelRecord, "Turn: 0" ); 
    
    glui->add_column( false );
	//  Control management
    GLUI_Panel *panelControlMode = glui->add_panel( "Control Mode" );
    ctrl_mode = glui->add_radiogroup_to_panel( panelControlMode, NULL,
                                               CONTROLMODE, control_cb );
    glui->add_radiobutton_to_group( ctrl_mode, "Automatic" );
    glui->add_radiobutton_to_group( ctrl_mode, "Manual" );

    panelRobot = glui->add_panel( "Robot Control" );
    vTran = glui->add_statictext_to_panel( panelRobot, "Translation: 0.00" );
    vRot = glui->add_statictext_to_panel( panelRobot, "Rotation:     0.00" );
    panelRobot->disable(); // Mode automatique par defaut

    glui->add_button( "Bye je t'Quit", 0, (GLUI_Update_CB) exit );
}

void update_user_interface_simulation_values()
{
	char temp[MAX_LINE];
	
	sprintf( temp, "Rate: %.3lf", simulation_get_deconRate() );
    rate->set_text( temp );
    
    sprintf( temp, "Turn: %d", turn_count );
    turn->set_text( temp );
}

void update_user_interface_control_values()
{
	char temp[MAX_LINE];
	
    sprintf( temp, "Translation: %.3lf", simulation_get_robot_vTran() );
    vTran->set_text( temp );
        
    sprintf( temp, "Rotation:     %.3lf", simulation_get_robot_vRot() );
    vRot->set_text( temp );
}

void mouse( int button, int state, int mouse_x, int mouse_y )
{
    if( ctrl_mode->get_int_val() == MANUAL 
		&& button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
	{
        double midwidth = glutGet( GLUT_WINDOW_WIDTH )/2,
               midheight = glutGet( GLUT_WINDOW_HEIGHT )/2;
        double scale, x, y;
        if( midwidth <= midheight ) scale = midwidth;
        else scale = midheight;

        x = (mouse_x-midwidth)*(double)DMAX/scale;
        y = (midheight-mouse_y)*(double)DMAX/scale;
            
		simulation_robotSelection( x, y );
		update_user_interface_control_values(); 
	}
}

void keyboard_special( int key, int x, int y )
{
	if( ctrl_mode->get_int_val() == MANUAL )
    {
		switch( key )
		{
			case GLUT_KEY_UP: 
				simulation_robot_vTran( UP ); // vTran++
				break;
			case GLUT_KEY_DOWN: 
				simulation_robot_vTran( DOWN ); // vTran--
				break;
			case GLUT_KEY_LEFT: 
				simulation_robot_vRot( LEFT ); // vRot++
				break;
			case GLUT_KEY_RIGHT: 
				simulation_robot_vRot( RIGHT ); // vRot--
				break;
		}
		update_user_interface_control_values();
	}
}

void keyboard( unsigned char key, int x, int y )
{
	if( key > MAJ) key -= ECART; // si lettre minuscule on la ramene a sa majuscule 

	if( define_file_selected_by_nb( key ) )
	{
		stop = true;
		simulation_initialisation( (const char*) file_selected_by_nb );
		prepare_new_simulation();
        start_stop->set_name( "Start" );
        fileOpen->set_text( file_selected_by_nb );
        return ;
	}
	switch( key )
	{
		case 'H' :
			system("cat Aa_ReadMe_Help.txt");
			break;
		case 'O' :
			control_cb( OPEN );
			break;
		case 'S' :
			control_cb( SAVE );
			break;
		case ENTER :
			control_cb( STARTSTOP );
			break;
		case SPACE :
			control_cb( STEPMODE );
			break;
		case 'R' :
			record = !record;
			GLUI_Master.sync_live_all(); // (un)tick la checkbox record
			break;
		case 'G' :
			system("gnuplot \"gnuplot_cmd.txt\"");
			break;
		case 'M' :
			ctrl_mode->set_int_val( !ctrl_mode->get_int_val() );
			control_cb( CONTROLMODE );
			break;
		case 'Q' :
			printf("Thank you!\n");
			exit( EXIT_SUCCESS );
	}		
}				
					
bool define_file_selected_by_nb( int key )
{
	switch( key )
	{ 
		case H1 :
			file_selected_by_nb = (char*) "D01.txt";
			return true;
		case H2 :
			file_selected_by_nb = (char*) "D02.txt";
			return true;
		case H3 :
			file_selected_by_nb = (char*) "D03.txt";
			return true;
		case H4 :
			file_selected_by_nb = (char*) "D04.txt";
			return true;
		case H5 :
			file_selected_by_nb = (char*) "D05.txt";
			return true;
		case H6 :
			file_selected_by_nb = (char*) "D06.txt";
			return true;
		case H7 :
			file_selected_by_nb = (char*) "D07.txt";
			return true;
		case H8 :
			file_selected_by_nb = (char*) "D08.txt";
			return true;
		case H9 :
			file_selected_by_nb = (char*) "D09.txt";
			return true;
		case HA :
			file_selected_by_nb = (char*) "ABC/SLALOM.txt";
			return true;
		case HB :
			file_selected_by_nb = (char*) "ABC/gama.txt";
			return true;
		case HC :
			file_selected_by_nb = (char*) "ABC/HYPNO.txt";
			return true;
		case HD :
			file_selected_by_nb = (char*) "ABC/testlin.txt";
			return true;
		case HE :
			file_selected_by_nb = (char*) "ABC/testrot.txt";
			return true;
		case HF :
			printf("Sorry - No file\n");
			break;
	}
	return false;
}
