//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef PARTICULE_H
#define PARTICULE_H

#include <stdio.h>
#include <stdbool.h>

#include "constantes.h"
#include "utilitaire.h"

///////////////////////////////FONCTIONS "FICHIER"/////////////////////////////////////

/*Gere la lecture du tableau extrait du fichier et crée les particules
 correspondantes*/
void particule_lecture(char ligne[MAX_LINE]);
/*Detecte si il y des erreurs dans les donnees des particules recuperee*/
bool particule_erreur(void);
/*Verifie si il y a une collsion entre le robot et une des particules, renvoie
 l'indice de la particule en collision*/
int particule_collisionRobotErreur(C2D robot);
/*Ecrit dans le fichier correspondant toutes les donnees des particules */
void particule_sauvegarde(FILE *fichier);
/*Libere toutes les structures de particules et reinitialisae les variables globales*/
void particule_toutEffacer(void);

///////////////////////////////FONCTIONS AFFICHAGE/////////////////////////////////////
/*Affiche dans le terminal les donnees de toutes les particules*/
void particule_afficher (void);
/*Appelle pour chaque particule la fonction d'utilitaire en charge du dessin
 des robots*/
void particule_dessin(void);

///////////////////////////////FONCTION ROBOT_PARTICULE////////////////////////////////
/*Trie la structure des particules en fonction de leurs rayon et assigne celle avec le
 plus gros rayon comme cible au robot*/
void particule_nouvelleCible(S2D robotCoordonnnees,C2D *robotCible,bool *actif);
/*Renvoie vraie si une particule existe avec ces coordonnees*/
bool particule_existence (S2D cible);
/*Supprime la particule correspondant a ces coordonnees*/
void particule_suppressionRobot(S2D cible);
/*Revoie vrai si un robot rentre en collision avec une particule*/
bool particule_collisionRobot(C2D robotAncien,C2D robotNouveau,
                              C2D *nouvelleCible,double *nouvelleDistance);
/*Modifie la structure de la particule pour que celles-ci devienne libre*/
void particule_liberer(S2D pos);

//////////////////////////////FONCTIONS SIMULATION/////////////////////////////////////

/*Pour chaque particule, la divise en 4 autres plus petite particules si besoin */
void particule_operation(void);

///////////////////////////////////FONCTIONS GET///////////////////////////////////////

/*Renvoie le nombre de robot*/
int particule_get_nbParticule(void);

/*Renvoie le taux de decontamination*/
double particule_get_deconRate(void);
#endif /* particle_h */
///////////////////////////////////////////////////////////////////////////////////////
