Given the 'coolness' of using a keyboard we developped a help menu,
it can be accessed when the program is launched from the terminal
by simply pressing 'H'.

Here is all the help you need...
	Open the file: press 'O'
		Quick access: press the hexadecimal value of the file's number
		Very helpful! :) (reset feature by pressing zero)
	Save the simulation: press 'S'

	To start/stop the simulation press 'ENTER'
	To make a single step press 'SPACE'
	To record or not the simulation (for GNUPLOT) press R
If you record the simulation, press 'G' to show its evolution during 6s

You can control a robot using the arrows
	To change the control mode press M
	Select a robot: click on it when manual mode active
	Deselect a robot: click somewhere, away from the robot

Exit? press 'Q

Thank you for using our program :)
If you like this may we get a top notch grade? :P
