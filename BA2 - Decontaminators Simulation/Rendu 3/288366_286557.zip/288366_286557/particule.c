//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "particule.h"
#include "error.h"

typedef struct Particule PARTICULE;

struct Particule
{
    double energie;
    C2D cercle;
    PARTICULE *prochain;
    PARTICULE *precedent;
    bool libre;
};

//////////////////////////VARIABLES GLOBALES AU MODULE/////////////////////////////////
static PARTICULE *teteListe = NULL;//Tete de liste,pointe sur la premiere particule

static int nbParticule = 0;
static double energieDepart=0;
static double energieDec=0;

/////////////////FONCTIONS NON EXPORTEES PAR LE MODULE/////////////////////////////////

/*Rajoute une nouvelle particule a la liste chainée*/
static void particule_creation (double energie, double rayon, double x, double y);
/*Trie la liste chainee des particules en ordre decroissant de rayon*/
static void particule_tri(void);
/*Libere la structure PARTICULE et referme la chaine*/
static void particule_suppression (PARTICULE *particule);
///////////////////////////////////////////////////////////////////////////////////////
static void particule_creation (double energie, double rayon, double x, double y)
{
    PARTICULE *nouveau = (PARTICULE*)malloc(sizeof(*nouveau));

    if (nouveau == NULL)
    {
        printf("%s:adressse NULL",__func__);
        exit(EXIT_FAILURE);
    }

    //L'ancien premier element recoit ce nouveau comme predecesseur
    if (teteListe != NULL) teteListe->precedent = nouveau;

    // L'element suivant ce nouvel element est l'ancien premier
    nouveau->prochain = teteListe;
    nouveau->precedent = NULL;
    teteListe = nouveau;

    nouveau->energie = energie;
    nouveau->cercle.rayon = rayon;
    nouveau->cercle.centre.x = x;
    nouveau->cercle.centre.y = y;
    nouveau->libre=true;    nbParticule++;
}

static void particule_suppression (PARTICULE *particule)
{
    if (particule==NULL)
    {
        printf("%s:adresse NULL",__func__);
        exit(EXIT_FAILURE);
    }
    if (particule->prochain)//Si la particule pointe sur une autre en prochain
    {
        particule->prochain->precedent = particule->precedent;
    }

    if (particule->precedent)//Si la particule possede un precedent
    {
        particule->precedent->prochain = particule->prochain;
    }

    else teteListe=particule->prochain;

    free(particule);

    nbParticule--;
}

void particule_suppressionRobot(S2D cible)
{
    PARTICULE* particule=teteListe;

    while (particule)
    {
        if (particule->cercle.centre.x==cible.x && particule->cercle.centre.y==cible.y)
        {
            energieDec+=particule->energie;
            particule_suppression(particule);
            return;
        }
        particule=particule->prochain;
    }
}

void particule_division (PARTICULE *particule)
{
    if ((double) rand()/(double)RAND_MAX <= DECOMPOSITION_RATE
        && particule->cercle.rayon*R_PARTICULE_FACTOR >= R_PARTICULE_MIN)
    {
        double nouveauRayon =particule->cercle.rayon *R_PARTICULE_FACTOR;
        double nouvelleEnergie = (particule->energie)*E_PARTICULE_FACTOR;

        particule_creation (nouvelleEnergie,nouveauRayon,
                            (particule->cercle.centre.x+nouveauRayon),
                            particule->cercle.centre.y+nouveauRayon);

        particule_creation (nouvelleEnergie,nouveauRayon,
                            (particule->cercle.centre.x+nouveauRayon),
                            particule->cercle.centre.y-nouveauRayon);

        particule_creation (nouvelleEnergie,nouveauRayon,
                            (particule->cercle.centre.x-nouveauRayon),
                            particule->cercle.centre.y+nouveauRayon);

        particule_creation (nouvelleEnergie,nouveauRayon,
                            (particule->cercle.centre.x-nouveauRayon),
                            particule->cercle.centre.y-nouveauRayon);

        particule_suppression(particule);
    }
}

void particule_lecture(char ligne[MAX_LINE])
{
    char *ptrligne = ligne;
    double particuleEnergie, particuleRayon, particuleX, particuleY;

    while(sscanf(ptrligne, " %lf %lf %lf %lf",
                 &particuleEnergie, &particuleRayon, &particuleX, &particuleY) == 4)
    {
        particule_creation(particuleEnergie, particuleRayon, particuleX, particuleY);
        energieDepart+=particuleEnergie;
        for(int i = 0; i < 4; i++) strtod(ptrligne,  &ptrligne);
    }
}

void particule_sauvegarde(FILE *fichier)
{
    PARTICULE *particule = teteListe;

    fprintf(fichier, "# nb_particule\n%d\n# info_particule\n", nbParticule);

    while(particule)
    {
        fprintf(fichier, "%lf %lf %lf %lf\n",
                particule->energie, particule->cercle.rayon,
                particule->cercle.centre.x, particule->cercle.centre.y);

        particule = particule->prochain;
    }

    fprintf(fichier,"FIN_LISTE\n");
}

bool particule_erreur()
{
    PARTICULE *particule1=teteListe;
    PARTICULE *particule2;

    double energie,rayon,dist;
    int i=1,j=1;
    S2D pos;

    while(particule1)
    {
        energie = particule1->energie;
        rayon = particule1->cercle.rayon;
        pos.x = particule1->cercle.centre.x;
        pos.y = particule1->cercle.centre.y;

        if (energie>E_PARTICULE_MAX || rayon<R_PARTICULE_MIN
            || rayon>R_PARTICULE_MAX || util_point_dehors(pos,DMAX))
        {
            error_invalid_particule_value(energie, rayon, pos.x, pos.y);
            return true;
        }
        particule1 = particule1->prochain;
    }

    particule1=teteListe;

    while(particule1)
    {
        particule2=particule1;
        j=i;

        while(particule2)
        {
            if (particule1!=particule2 &&
                util_collision_cercle(particule1->cercle,particule2->cercle,&dist))
            {
                error_collision(PARTICULE_PARTICULE,nbParticule-i,nbParticule-j);
                return true;
            }
            particule2=particule2->prochain;
            j++;
        }
        particule1=particule1->prochain;
        i++;
    }
    return false;
}

int particule_collisionRobotErreur(C2D robot)
{
    int i=0;
    double dist;
    PARTICULE *particule=teteListe;
    while (particule)
    {
        if(util_collision_cercle(particule->cercle,robot,&dist)) return nbParticule-i;

        i++;
        particule=particule->prochain;
    }

    return 0;
}

bool particule_collisionRobot(C2D robotAncien,C2D robotNouveau,
                              C2D *nouvelleCible,double *nouvelleDistance)
{
    PARTICULE *particule=teteListe;
    double distanceParcouru=util_distance(robotAncien.centre, robotNouveau.centre);//la
    double nouvelleDistCentre;//lb: distance entre les centres apres avoir avoir avance
    double ancienneDistCentre;//lc:distance entre les centres avant d'avance
    double sommeRayon;//lb_new

    while(particule)
    {
        if(util_collision_cercle(robotNouveau, particule->cercle, &nouvelleDistCentre))
        {
            sommeRayon=robotAncien.rayon+particule->cercle.rayon;
            ancienneDistCentre=util_distance(robotAncien.centre, particule->cercle.centre);

            particule_liberer(nouvelleCible->centre);//Libere l'ancienne cible
            *nouvelleCible=particule->cercle;//Assigne cette particule
                                             //comme nouvelle cible

            util_inner_triangle(distanceParcouru, nouvelleDistCentre,
                                ancienneDistCentre,sommeRayon,nouvelleDistance);

            return true;
        }
        particule=particule->prochain;
    }

    return false;
}

static void particule_tri(void)
{
    PARTICULE *particule = teteListe;

    PARTICULE *tempA=NULL;
    PARTICULE *tempB=NULL;
    PARTICULE *tempC=NULL;
    PARTICULE *tempD=NULL;
    bool finTri=false;


    if(teteListe)
        while(!finTri)
        {
            particule=teteListe;
            finTri=true;
            while(particule->prochain)
            {

                if(particule->prochain->cercle.rayon>particule->cercle.rayon)
                {
                    finTri=false;

                    tempA=particule->precedent;
                    tempB=particule;
                    tempC=particule->prochain;
                    tempD=particule->prochain->prochain;

                    //Inverse les deux particules en ordre decroissant

                    if(tempA)tempA->prochain=tempC;

                    else teteListe=tempC;

                    tempB->precedent=tempC;

                    tempB->prochain=tempD;

                    tempC->precedent=tempA;

                    tempC->prochain=tempB;

                    if (tempD)tempD->precedent=tempB;
                }

                else particule=particule->prochain;

            }
        }
}

void particule_afficher (void)
{
    PARTICULE *particule=teteListe;

    while(particule)
    {
        printf("\nEnergie:%lf Rayon:%lf x:%f y:%f\n",particule->energie,
               particule->cercle.rayon,particule->cercle.centre.x,
               particule->cercle.centre.y);

        if(particule->libre)printf("Libre\n");
        else printf("Occupe\n");
        particule=particule->prochain;
    }
}

void particule_toutEffacer()
{
    PARTICULE *particule=teteListe;

    while(particule)
    {
        particule_suppression(particule);
        particule=teteListe;
    }
    teteListe=NULL;
    nbParticule=0;
    energieDepart=0;
    energieDec=0;
}

int particule_get_nbParticule(void)
{
    return nbParticule;
}

void particule_nouvelleCible(S2D robotCoordonnnees,C2D *robotCible,bool *actif)
{
    PARTICULE *particule=teteListe;

    while(particule)
    {
        if (particule->libre==true)
        {
            *robotCible=particule->cercle;
            particule->libre=false;
            return;
        }
        particule=particule->prochain;
    }
    *actif=false;
}

bool particule_existence (S2D cible)
{
    PARTICULE* particule=teteListe;

    while (particule)
    {
        if(particule->cercle.centre.x==cible.x &&
           particule->cercle.centre.y==cible.y) return true;

        particule=particule->prochain;
    }
    return false;
}

void particule_operation(void)
{
    PARTICULE *particule=teteListe;
    while(particule)
    {
        particule_division(particule);
        particule=particule->prochain;
    }
    particule_tri();
}

double particule_get_deconRate(void)
{
    return 100*(energieDec/energieDepart);
}

void particule_liberer(S2D pos)
{
    PARTICULE *particule=teteListe;

    while (particule)
    {
        if (particule->cercle.centre.x==pos.x &&particule->cercle.centre.y==pos.y)
        {
            particule->libre=true;
            return;
        }
        particule=particule->prochain;
    }
}

void particule_dessin(void)
{
    PARTICULE *particule=teteListe;
    while(particule)
    {
		int epaisseur = FIN;
		
		if(particule->energie > 0.75)
			util_dessin_cercle(particule->cercle, FILLED, ROUGE, epaisseur);
		else if(particule->energie > 0.50) 
			util_dessin_cercle(particule->cercle, FILLED, BLEU, epaisseur);
		else if(particule->energie > 0.25) 
			util_dessin_cercle(particule->cercle, FILLED, VERT, epaisseur);
		else 
			util_dessin_cercle(particule->cercle, FILLED, BRUN, epaisseur);
		
		if(!particule->libre) // indication si particule selectionnee par un robot
		{
			double x = particule->cercle.centre.x, y = particule->cercle.centre.y;
			double dist = particule->cercle.rayon*cos(M_PI_4); // = rayon*sin(M_PI/4)
			if(particule->cercle.rayon > R_PARTICULE_MIN) epaisseur = MOYEN;
			
			util_dessin_ligne(x-dist, y-dist, x+dist, y+dist, ORANGE, epaisseur);
			util_dessin_ligne(x-dist, y+dist, x+dist, y-dist, ORANGE, epaisseur);
						  
			util_dessin_cercle(particule->cercle, EMPTY, JAUNE, epaisseur);
		}
        particule=particule->prochain;
    }
}


