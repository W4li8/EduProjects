//
//  graphic.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#include <GL/glu.h>
#include <math.h>

#include "graphic.h"
#include "constantes.h"

#define COTES 60

void graphic_line_width(int width) 
{
	glLineWidth(width);
}

void graphic_set_colour(int colour) 
{
	switch(colour)
	{
		case BLANC:
			glColor3f(1, 1, 1);
			break;
		case NOIR:
			glColor3f(0, 0, 0);
			break;
		case VIOLET:
			glColor3f(0.6, 0.2,1);
			break;
		case BRUN:
			glColor3f(0.4, 0.2, 0);
			break;
		case VERT:
			glColor3f(0.2, 0.4, 0);
			break;
		case BLEU:
			glColor3f(0, 0.3, 0.6);
			break;
		case RED:
			glColor3f(1, 0, 0);
			break;
		case ROUGE:
			glColor3f(0.8, 0, 0);
			break;
		case ORANGE:
			glColor3f(1, 0.5, 0);
			break;
		case JAUNE:
			glColor3f(1, 1, 0);
			break;
		case GRIS:
			glColor3f(0.4, 0.4, 0.4);
			break;
	}
}

void graphic_ligne(double x1, double y1, double x2, double y2)
{
    glBegin(GL_LINES);
    
    glVertex2f (x1, y1);
    glVertex2f (x2, y2);
    
    glEnd ();
}

void graphic_cercle(double rayon, double x, double y, int type)
{
	glBegin(type ? GL_POLYGON : GL_LINE_LOOP);
	
    for (int i = 0; i < COTES; i++)
    {
        double alfa = i*2*M_PI/COTES;
        glVertex2f(x+rayon*cos(alfa), y+rayon*sin(alfa));
    }
    glEnd();
}
