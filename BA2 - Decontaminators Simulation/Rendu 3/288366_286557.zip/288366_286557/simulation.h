//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//

#ifndef SIMULATION_H

#define SIMULATION_H

/////////////////////////////////FONCTIONS FICHIER/////////////////////////////////////

/*Met a true le booléen modeError qui est a false de base*/
void simulation_activer_modeErreur(void);
/*Lit le fichier,verifie si il y a des erreurs et envoie ces données
 à robot et particule*/
void simulation_initialisation(const char fichier[]);
/*Enregistre l'etat courant de la simulation dans le fichier .txt*/
void simulation_sauvegarde(const char *ptr_fichier);
/*Enregistre le taux de decontamination et le nombre de tour dans le fichier out.dat*/
void simulation_enregistrement(int tour);

/////////////////////////////FONCTIONS "FEEDBACK" MAIN/////////////////////////////////

/*Lance la simulation d'un tour complet en appelant les fonctions
 de robot et particule*/
void simulation_operations(void);
/*Dessine l'etat actuel du monde*/
void simulation_dessin(void);
/*Renvoie true si le taux de decontamination est a 100*/
bool simulation_finDecontamination(void);

///////////////////////////////////FONCTIONS CONTROLE ROBOT////////////////////////////

/*Selectionne un robot en appelant robot_selection*/
void simulation_robotSelection(double x, double y);
/*Deselectionne un robot en appelant robot_deselection*/
void simulation_robotDeselection(void);
/*Met a jour la vitesse de translation du robot controle manuellement*/
void simulation_robot_vTran(int multiplier);
/*Met a jour la vitesse de rotation du robot controle manuellement*/
void simulation_robot_vRot(int multiplier);

///////////////////////////////////////FONCTIONS GET///////////////////////////////////

/*Renvoie le taux de decontamination*/
double simulation_get_deconRate(void);
/*Renvoie la vitesse de translation du robot controlle manuellement*/
double simulation_get_robot_vTran(void);
/*/*Renvoie la vitesse de rotation du robot controlle manuellement*/
double simulation_get_robot_vRot(void);

#endif /* gestionfichier_h */
