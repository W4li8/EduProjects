//
//  main.c
//
//  Created by Filip Slezak and Antoine Masanet.
//  Project Spring 2018 Decontaminators.
//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "robot.h"
#include "particule.h"
#include "error.h"
#include "utilitaire.h"
#include "tolerance.h"

typedef struct Robot ROBOT;
struct Robot
{
    C2D cercle;
    double angle;
    C2D cible;
    double vTran;
    double vRot;
    ROBOT* prochain;
    bool actif;
    bool autonome;
};

//////////////////////////VARIABLES GLOBALES AU MODULE/////////////////////////////////
static ROBOT *teteListe;//Pointeur de tete de la liste chainee

static int nbRobot=0;
static C2D cibleImaginaire={{100,100},4};
static double vTran;
static double vRot;

/////////////////FONCTIONS NON EXPORTEES PAR LE MODULE/////////////////////////////////

/*Gere les collisions possible du robot lors de son deplacement et modifie sa position
 le cas echeant*/
static void robot_collisionTotal(ROBOT *robot,C2D robotNouveau);
/*Renvoie vrai si il y une collision entre le robot et un des robots de la simulation*/
static bool robot_collisionRobot(ROBOT *robot,C2D robotNouveau);
/*Rajoute un nouveau robot a la liste chainée*/
static void robot_creation (double x, double y, double angle);
/*Gere le deplacement du robot et, le cas echeant, la decontamination de la particule
 ciblee*/
static void robot_deplacement (ROBOT *robot);
///////////////////////////////////////////////////////////////////////////////////////

static void robot_creation (double x, double y, double angle)
{
    //Alloue de la memoire pour le nouvel element
    ROBOT *nouveau = malloc(sizeof(*nouveau));

    if (nouveau == NULL)
    {
        printf("%s:adressse NULL",__func__);
    }

    //L'element suivant ce nouvel element est l'ancien premier
    nouveau->prochain = teteListe;
    teteListe = nouveau;

    nouveau->angle=angle;
    nouveau->cercle.rayon = R_ROBOT;;
    nouveau->cercle.centre.x = x;
    nouveau->cercle.centre.y = y;
    nouveau->vTran=VTRAN_MAX;
    nouveau->vRot=VROT_MAX;
    nouveau->autonome=true;
    nouveau->actif=false;

    //Cible fictive
    nouveau->cible=cibleImaginaire;
    nbRobot++;
}

void robot_lecture(char ligne[MAX_LINE])
{
    char *ptrligne = ligne;
    double robotX, robotY, robotAngle;

    while(sscanf(ptrligne, " %lf %lf %lf", &robotX, &robotY, &robotAngle) == 3)
    {
        robot_creation(robotX, robotY, robotAngle);
        for(int i = 0; i < 3; i++) strtod(ptrligne,  &ptrligne);
    }
}

void robot_sauvegarde(FILE *fichier)
{
    ROBOT* robot=teteListe;

    fprintf(fichier, "# nb_robot\n%d\n# info_robot\n",nbRobot);

    while (robot)
    {
        fprintf(fichier, "%f %f %f\n",robot->cercle.centre.x,
                robot->cercle.centre.y,robot->angle);

        robot=robot->prochain;
    }
    fprintf(fichier,"FIN_LISTE\n\n");
}

bool robot_erreur()
{
    int i=0,j=0;
    ROBOT *robot1=teteListe,*robot2=NULL;
    double dist;//Necessaire pour employer l'utilitaire

    while(robot1)
    {
        if (util_alpha_dehors(robot1->angle))
        {
            error_invalid_robot_angle(robot1->angle);
            return true;
        }
        robot1=robot1->prochain;
    }

    robot1=teteListe;
    while(robot1)
    {
        robot2=robot1;
        j=0;
        while(robot2)
        {
            if (robot1!=robot2 && util_collision_cercle(robot1->cercle,
                                                        robot2->cercle,&dist))
            {
                //Remet les indices dans le bon ordre
                error_collision(ROBOT_ROBOT,nbRobot-i,nbRobot-j);
                return true;
            }
            robot2=robot2->prochain;
            j++;
        }
        robot1=robot1->prochain;
        i++;
    }
    robot1=teteListe;
    i=0;
    while(robot1)
    {
        //Renvoie l'indice de la particule et 0 si pas de collision
        j=particule_collisionRobotErreur(robot1->cercle);
        if (j)
        {
            //Remet les indices dans le bon ordre
            error_collision(ROBOT_PARTICULE,nbRobot-i,j);
        }
        robot1=robot1->prochain;
        i++;
    }
    return false;
}

static void robot_deplacement (ROBOT *robot)
{
    C2D robotNouveau=robot->cercle;
    double distanceCible,deltaAngle;
    bool deplacement=true;
    robot->actif=true;//remet par defaut le robot actif
    robot->vRot=VROT_MAX;
    robot->vTran=VTRAN_MAX;
    
    if(!particule_existence(robot->cible.centre))//Si la cible n'existe plus
        particule_nouvelleCible(robot->cercle.centre,&robot->cible,&robot->actif);
    
        util_ecart_angle(robot->cercle.centre,robot->angle,
                         robot->cible.centre,&deltaAngle);
        distanceCible=util_distance(robot->cercle.centre, robot->cible.centre)
                                    -(robot->cercle.rayon+robot->cible.rayon);
    
    if (distanceCible>-EPSIL_ZERO && distanceCible<EPSIL_ZERO &&
        deltaAngle>-EPSIL_ALIGNEMENT &&deltaAngle<EPSIL_ALIGNEMENT )
        particule_suppressionRobot(robot->cible.centre);
    
    
    if (robot->actif && robot->autonome)
    {
        if (deltaAngle>=robot->vRot*DELTA_T) robot->angle+=robot->vRot*DELTA_T;

        else if (deltaAngle<=-robot->vRot*DELTA_T) robot->angle-=robot->vRot*DELTA_T;

        else
        {
            robot->vRot=deltaAngle/DELTA_T;
            robot->angle+=robot->vRot*DELTA_T;
        }
        if(deltaAngle<M_PI_4 && deltaAngle>-M_PI_4)
        {
            if (distanceCible>=robot->vTran*DELTA_T)
                robotNouveau.centre=util_deplacement(robot->cercle.centre,robot->angle,
                                                     robot->vTran*DELTA_T);

            else
            {
                robot->vTran=distanceCible/DELTA_T;
                robotNouveau.centre=util_deplacement(robot->cercle.centre,robot->angle,
                                                     robot->vTran*DELTA_T);
            }
        }
    }
    else if (!robot->autonome)
    {
        robot->angle+=vRot*DELTA_T;
        robotNouveau.centre=util_deplacement(robot->cercle.centre,
                                             robot->angle, vTran*DELTA_T);
    }
    else deplacement=false;//Si il est inactif

    //Gere "UNE" collision possible et le positionnement du robot consequent
    if (deplacement)robot_collisionTotal(robot,robotNouveau);
}

static void robot_collisionTotal(ROBOT *robot,C2D robotNouveau)
{
    C2D robotAncien=robot->cercle;
    double nouvelleDistance;

    //Si il y a collision avec un robot,la position du robot est updater, il change de
    //cible et ne bouge pas
    if(robot_collisionRobot(robot, robotNouveau))
    {
        particule_liberer(robot->cible.centre);
        //Cree une cible impossible pour le forcer a changer de cible par la suite
        robot->cible=cibleImaginaire;
    }
    //Il n'y a pas de collision, le robot va ou il devait
    else robot->cercle.centre=robotNouveau.centre;

    //Gere la collision  avec des particules et fait en sorte que celle-ci devienne sa cible
    //pour decontaminer cette particule
    if (particule_collisionRobot(robotAncien, robot->cercle, &robot->cible,
                                 &nouvelleDistance))
        robot->cercle.centre=util_deplacement(robotAncien.centre,
                                              robot->angle,nouvelleDistance);
}

static bool robot_collisionRobot(ROBOT *robot1,C2D robotNouveau)
{
    ROBOT *robot2=teteListe;
    double nouvelleDistCentre; //Necessaire pour employer la fonction de l'utilitaire
    while(robot2)
    {
        if(robot1!=robot2)
            if(util_collision_cercle(robotNouveau, robot2->cercle,
                                     &nouvelleDistCentre))return true;

        robot2=robot2->prochain;
    }
    return false;
}

void robot_toutEffacer()
{
    ROBOT *robot=teteListe;
    ROBOT *temp;

    while(robot)
    {
        temp=robot->prochain;
        free(robot);
        robot=temp;
    }
    teteListe=NULL;
    nbRobot=0;
}

void robot_afficher(void)
{
    ROBOT* robot=teteListe;
    while(robot)
    {
        printf("x:%lf y:%lf Angle:%lf\n",robot->cercle.centre.x,
               robot->cercle.centre.y,robot->angle);
        printf("Cible: x:%lf y:%lf Rayon:%lf\n",robot->cible.centre.x,
               robot->cible.centre.y,robot->cible.rayon);
        robot=robot->prochain;

    }
}

void robot_operation()
{
    ROBOT *robot=teteListe;
    while(robot)
    {
        robot_deplacement(robot);
        robot=robot->prochain;
    }
}

void robot_selection (double x, double y)
{
    ROBOT *robot=teteListe;
    S2D a={x,y};
    
    robot_deselection();
    
    robot=teteListe;
    
    while(robot)
    {
        if (util_point_dans_cercle(a, robot->cercle))
        {
            robot->autonome=false;
            return;
        }
        robot=robot->prochain;
    }
}

void robot_vTran(int multiplier)
{
    if(fabs(vTran+multiplier*DELTA_VTRAN) < VTRAN_MAX) vTran += multiplier*DELTA_VTRAN;
    else vTran = multiplier*VTRAN_MAX;
}

void robot_vRot(int multiplier)
{
    if(fabs(vRot+multiplier*DELTA_VROT) < VROT_MAX) vRot += multiplier*DELTA_VROT;
    else vRot = multiplier*VROT_MAX;
    
}

void robot_dessin(void)
{
    ROBOT *robot=teteListe;
    while(robot)
    {
		double x = robot->cercle.centre.x, y = robot->cercle.centre.y;
		double alpha = robot->angle;
		util_dessin_cercle(robot->cercle, FILLED, BLANC, FIN);		
		util_dessin_cercle(robot->cercle, EMPTY, robot->autonome ? NOIR : RED, FIN);
		
		util_dessin_ligne(x, y, x+R_ROBOT*cos(alpha), y+R_ROBOT*sin(alpha), 
						  VIOLET, FIN);
		
        robot=robot->prochain;
    }
}

int robot_get_nbRobot()
{
    return nbRobot;
}

double robot_get_vTran()
{
    return vTran;
}

double robot_get_vRot()
{
    return vRot;
}

void robot_deselection(void)
{
    ROBOT *robot=teteListe;
    while(robot)
    {
        robot->autonome=true;
        robot=robot->prochain;
    }
    //Reinitialisae les vitesses
    vTran=0;
    vRot=0;
}
///////////////////////////////////////////////////////////////////////////////////////
